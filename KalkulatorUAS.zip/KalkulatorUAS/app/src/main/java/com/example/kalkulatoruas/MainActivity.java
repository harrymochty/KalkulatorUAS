package com.example.kalkulatoruas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2;
    private TextView tv2;
    private Button bt1;
    private RadioButton rd1,rd2,rd3,rd4;
    SharedPreferences.Editor history;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1=(EditText)findViewById(R.id.et1);
        et2=(EditText)findViewById(R.id.et2);
        tv2=(TextView) findViewById(R.id.tv2);
        history = getSharedPreferences("history" , MODE_PRIVATE).edit();
        rd1=(RadioButton) findViewById(R.id.rd1);
        rd2=(RadioButton) findViewById(R.id.rd2);
        rd3=(RadioButton) findViewById(R.id.rd3);
        rd4=(RadioButton) findViewById(R.id.rd4);
        bt1=(Button) findViewById(R.id.bt1);


        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String bilangan1_String = et1.getText().toString();
                String bilangan2_String = et2.getText().toString();

                int bilangan1_int = Integer.parseInt(bilangan1_String);
                int bilangan2_int = Integer.parseInt(bilangan2_String);

                if (rd1.isChecked()==true){
                    int tmbh = bilangan1_int +bilangan2_int;
                    String hasil= String.valueOf(tmbh);
                    tv2.setText(hasil);
                }else if (rd2.isChecked()==true) {
                    int krng = bilangan1_int - bilangan2_int;
                    String hasil = String.valueOf(krng);
                    tv2.setText(hasil);
                }else if (rd3.isChecked()==true) {
                    int kali = bilangan1_int * bilangan2_int;
                    String hasil = String.valueOf(kali);
                    tv2.setText(hasil);
                }else if(rd4.isChecked()==true){
                    int bagi = bilangan1_int / bilangan2_int;
                    String hasil = String.valueOf(bagi);
                    tv2.setText(hasil);
                }

                history.putString("history_hitung", et1.getText().toString());
                history.apply();

            }

        });
    }


    public void Calculator(View view){
        String bilangan1_String = et1.getText().toString();
        String bilangan2_String = et2.getText().toString();

        int bilangan1_int = Integer.parseInt(bilangan1_String);
        int bilangan2_int = Integer.parseInt(bilangan2_String);

        if (rd1.isChecked()==true){
            int tmbh = bilangan1_int +bilangan2_int;
            String hasil= String.valueOf(tmbh);
            tv2.setText(hasil);
        }else if (rd2.isChecked()==true) {
            int krng = bilangan1_int - bilangan2_int;
            String hasil = String.valueOf(krng);
            tv2.setText(hasil);
        }else if (rd3.isChecked()==true) {
            int kali = bilangan1_int * bilangan2_int;
            String hasil = String.valueOf(kali);
            tv2.setText(hasil);
        }else if(rd4.isChecked()==true){
            int bagi = bilangan1_int / bilangan2_int;
            String hasil = String.valueOf(bagi);
            tv2.setText(hasil);
        }
    }
}